var wms_layers = [];

var format_a0000003aRelTypes_0 = new ol.format.GeoJSON();
var features_a0000003aRelTypes_0 = format_a0000003aRelTypes_0.readFeatures(json_a0000003aRelTypes_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_a0000003aRelTypes_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_a0000003aRelTypes_0.addFeatures(features_a0000003aRelTypes_0);
var lyr_a0000003aRelTypes_0 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_a0000003aRelTypes_0, 
                style: style_a0000003aRelTypes_0,
                popuplayertitle: 'a0000003a — RelTypes',
                interactive: true,
    title: 'a0000003a — RelTypes<br />\
    <img src="styles/legend/a0000003aRelTypes_0_0.png" /> Аккумулятивные горизонтальные и субгоризонтальные поверхности (с глубоким (>25 м) залеганием коренных пород)<br />\
    <img src="styles/legend/a0000003aRelTypes_0_1.png" /> Аккумулятивные горизонтальные и субгоризонтальные поверхности (c неглубоким (до 25м) залеганием коренных пород)<br />\
    <img src="styles/legend/a0000003aRelTypes_0_2.png" /> Аккумулятивные склоны, переработанные последующими денудационными процессами (с глубоким (>25 м) залеганием коренных пород)<br />\
    <img src="styles/legend/a0000003aRelTypes_0_3.png" /> Аккумулятивные склоны, переработанные последующими денудационными процессами (c неглубоким (до 25м) залеганием коренных пород)<br />\
    <img src="styles/legend/a0000003aRelTypes_0_4.png" /> Бечевник<br />\
    <img src="styles/legend/a0000003aRelTypes_0_5.png" /> Высокая пойма<br />\
    <img src="styles/legend/a0000003aRelTypes_0_6.png" /> I Надпойменная терраса<br />\
    <img src="styles/legend/a0000003aRelTypes_0_7.png" /> Днища оврагов и балок<br />\
    <img src="styles/legend/a0000003aRelTypes_0_8.png" /> Ложбины стока талых ледниковых вод<br />\
    <img src="styles/legend/a0000003aRelTypes_0_9.png" /> Нерасчлененный комплекс надпойменных террас<br />\
    <img src="styles/legend/a0000003aRelTypes_0_10.png" /> Низкая пойма<br />\
    <img src="styles/legend/a0000003aRelTypes_0_11.png" /> Поверхности долинных зандров<br />\
    <img src="styles/legend/a0000003aRelTypes_0_12.png" /> Средняя пойма<br />\
    <img src="styles/legend/a0000003aRelTypes_0_13.png" /> Структурно-натечные псевдотеррасы, обусловленные накоплением травертина<br />\
    <img src="styles/legend/a0000003aRelTypes_0_14.png" /> Эрозионные склоны крутые<br />\
    <img src="styles/legend/a0000003aRelTypes_0_15.png" /> Эрозионные склоны пологие<br />\
    <img src="styles/legend/a0000003aRelTypes_0_16.png" /> II Надпойменная терраса<br />\
    <img src="styles/legend/a0000003aRelTypes_0_17.png" /> III Надпойменная терраса<br />\
    <img src="styles/legend/a0000003aRelTypes_0_18.png" /> <br />' });

lyr_a0000003aRelTypes_0.setVisible(true);
var layersList = [lyr_a0000003aRelTypes_0];
lyr_a0000003aRelTypes_0.set('fieldAliases', {'OBJECTID': 'OBJECTID', 'RelType': 'Тип рельефа', 'ID': 'ID', 'SHAPE_Length': 'SHAPE_Length', 'SHAPE_Area': 'SHAPE_Area', });
lyr_a0000003aRelTypes_0.set('fieldImages', {'OBJECTID': 'TextEdit', 'RelType': 'TextEdit', 'ID': 'Range', 'SHAPE_Length': 'TextEdit', 'SHAPE_Area': 'TextEdit', });
lyr_a0000003aRelTypes_0.set('fieldLabels', {'OBJECTID': 'no label', 'RelType': 'inline label - always visible', 'ID': 'no label', 'SHAPE_Length': 'no label', 'SHAPE_Area': 'no label', });
lyr_a0000003aRelTypes_0.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});